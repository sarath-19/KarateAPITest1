package cucumber.api.cli;

public class Main {
	public static void main(String[] args) {
        com.intuit.karate.cli.IdeMain.main(args);
    }  

}
